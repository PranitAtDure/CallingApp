import React from "react";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";

function MobileLayout() {}

export default MobileLayout;
